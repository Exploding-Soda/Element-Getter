// popup.js
document.addEventListener('DOMContentLoaded', function () {
  let prestyleList = document.getElementById('prestyle-list');
  let copyButton = document.getElementById('copy-button');

  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.scripting.executeScript({
      target: {tabId: tabs[0].id},
      func: getPrestyleElements
    }, (results) => {
      if (results && results[0] && results[0].result) {
        results[0].result.forEach(item => {
          let li = document.createElement('li');
          li.textContent = item;
          let button = document.createElement('button');
          button.textContent = "Copy";
          button.addEventListener('click', function() {
            navigator.clipboard.writeText(item).then(() => {
              alert('Item copied to clipboard!');
            }).catch(err => {
              console.error('Failed to copy: ', err);
            });
          });
          li.appendChild(button);
          prestyleList.appendChild(li);
        });
      }
    });
  });

  copyButton.addEventListener('click', function() {
    let textToCopy = '';
    let items = prestyleList.getElementsByTagName('li');
    for (let item of items) {
      textToCopy += item.textContent.replace('Copy', '').trim() + '\n';
    }

    navigator.clipboard.writeText(textToCopy).then(() => {
      alert('List copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  });
});

function getPrestyleElements() {
  let elements = document.getElementsByClassName("prestyle");
  let content = [];
  for (let element of elements) {
    content.push(element.textContent);
  }
  return content;
}
