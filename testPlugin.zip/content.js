// content.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPrestyleElements") {
    let elements = document.getElementsByClassName("prestyle");
    let content = [];
    for (let element of elements) {
      content.push(element.textContent);
    }
    sendResponse({content: content});
  }
});
